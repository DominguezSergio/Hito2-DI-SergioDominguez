function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["camara-camara-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/camara/camara.page.html":
  /*!*******************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/camara/camara.page.html ***!
    \*******************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppCamaraCamaraPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-button expand=\"full\" routerLink=\"/camara\" color=\"success\" size=\"small\">Camara</ion-button>\n    <ion-button expand=\"full\" routerLink=\"/home\" color=\"success\" size=\"small\">Inicio</ion-button>\n    <ion-title>camara</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div>\n    <ion-button (click)=\"captureImage()\">Click Picture</ion-button>\n    \n    <img [src]=\"clickedImage\" />\n  </div>\n  <ion-item-divider></ion-item-divider>\n  <ion-item>\n    <ion-label>Fecha</ion-label>\n    <ion-datetime value=\"1990-02-19\" placeholder=\"Selecciona una fecha\"></ion-datetime>\n  </ion-item>\n</ion-content>\n<!-- Footer without a border -->\n<div>\n<ion-footer>\n  <ion-toolbar>\n    <ion-title><a href=\"https://github.com/DominguezSergio/Hito2-DI-SergioDominguez\" target=\"_blank\">GitHub</a></ion-title>\n  </ion-toolbar>\n</ion-footer>\n</div>";
    /***/
  },

  /***/
  "./src/app/camara/camara-routing.module.ts":
  /*!*************************************************!*\
    !*** ./src/app/camara/camara-routing.module.ts ***!
    \*************************************************/

  /*! exports provided: CamaraPageRoutingModule */

  /***/
  function srcAppCamaraCamaraRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CamaraPageRoutingModule", function () {
      return CamaraPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _camara_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./camara.page */
    "./src/app/camara/camara.page.ts");

    var routes = [{
      path: '',
      component: _camara_page__WEBPACK_IMPORTED_MODULE_3__["CamaraPage"]
    }];

    var CamaraPageRoutingModule = function CamaraPageRoutingModule() {
      _classCallCheck(this, CamaraPageRoutingModule);
    };

    CamaraPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], CamaraPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/camara/camara.module.ts":
  /*!*****************************************!*\
    !*** ./src/app/camara/camara.module.ts ***!
    \*****************************************/

  /*! exports provided: CamaraPageModule */

  /***/
  function srcAppCamaraCamaraModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CamaraPageModule", function () {
      return CamaraPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _camara_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./camara-routing.module */
    "./src/app/camara/camara-routing.module.ts");
    /* harmony import */


    var _camara_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./camara.page */
    "./src/app/camara/camara.page.ts");

    var CamaraPageModule = function CamaraPageModule() {
      _classCallCheck(this, CamaraPageModule);
    };

    CamaraPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _camara_routing_module__WEBPACK_IMPORTED_MODULE_5__["CamaraPageRoutingModule"]],
      declarations: [_camara_page__WEBPACK_IMPORTED_MODULE_6__["CamaraPage"]]
    })], CamaraPageModule);
    /***/
  },

  /***/
  "./src/app/camara/camara.page.scss":
  /*!*****************************************!*\
    !*** ./src/app/camara/camara.page.scss ***!
    \*****************************************/

  /*! exports provided: default */

  /***/
  function srcAppCamaraCamaraPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NhbWFyYS9jYW1hcmEucGFnZS5zY3NzIn0= */";
    /***/
  },

  /***/
  "./src/app/camara/camara.page.ts":
  /*!***************************************!*\
    !*** ./src/app/camara/camara.page.ts ***!
    \***************************************/

  /*! exports provided: CamaraPage */

  /***/
  function srcAppCamaraCamaraPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CamaraPage", function () {
      return CamaraPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic-native/camera/ngx */
    "./node_modules/@ionic-native/camera/ngx/index.js");

    var CamaraPage =
    /*#__PURE__*/
    function () {
      function CamaraPage(camera) {
        _classCallCheck(this, CamaraPage);

        this.camera = camera;
        this.options = {
          quality: 30,
          destinationType: this.camera.DestinationType.DATA_URL,
          encodingType: this.camera.EncodingType.JPEG,
          mediaType: this.camera.MediaType.PICTURE
        };
      } //Camara


      _createClass(CamaraPage, [{
        key: "captureImage",
        value: function captureImage() {
          var _this = this;

          this.camera.getPicture(this.options).then(function (imageData) {
            // imageData is either a base64 encoded string or a file URI
            // If it's base64 (DATA_URL):
            var base64Image = 'data:image/jpeg;base64,' + imageData;
            _this.clickedImage = base64Image;
          }, function (err) {
            console.log(err); // Handle error
          });
        }
      }, {
        key: "ngOnInit",
        value: function ngOnInit() {}
      }]);

      return CamaraPage;
    }();

    CamaraPage.ctorParameters = function () {
      return [{
        type: _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_2__["Camera"]
      }];
    };

    CamaraPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-camara',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./camara.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/camara/camara.page.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./camara.page.scss */
      "./src/app/camara/camara.page.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_2__["Camera"]])], CamaraPage);
    /***/
  }
}]);
//# sourceMappingURL=camara-camara-module-es5.js.map